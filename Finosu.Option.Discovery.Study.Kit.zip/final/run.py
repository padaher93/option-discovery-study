from pathlib import Path
import json,hashlib,datetime,subprocess,concurrent.futures
from model_transport import model_call
R=Path(__file__).resolve().parent

def tool_result(req,c):
    name=req['name']
    try: args=json.loads(req['arguments_json'])
    except Exception:return {'error':'Invalid JSON arguments; use an object.'}
    if not isinstance(args,dict): return {'error':'Arguments must be a JSON object.'}
    if name in ['show_payment_cta','show_relief_options']:
        if set(args)-{'loan_id'}:return {'error':'Only the optional loan_id argument is accepted; no amount or payment execution is supported.'}
        if args.get('loan_id',c['account']['loan_id']) not in [None,c['account']['loan_id']]:return {'error':'No owned loan matches this identifier.'}
    if name in c['tool_state']:return c['tool_state'][name]
    defaults={'lookup_loans':{'loans':[c['account']]},'get_active_plans':{'plans':[]},'get_payment_history':{'payments':[]},'get_autopay_status':{'enabled':False},'get_payment_methods':{'methods':[],'guidance':'The borrower selects and authorizes a method in the portal.'},'recall_chat_memory':{'found':False},'draft_support_email':{'status':'draft_only','sent':False,'guidance':'Only a draft is shown for borrower review; no message was sent and no terms changed.'},'show_deferral_option':{'eligible':False,'reason':'No active plan','guidance':'Do not promise a deferral.'}}
    return defaults.get(name,{'error':'Unknown tool.'})

def run(job,cases):
    out=R/'results'/f"{job['case_id']}__{job['condition']}__r{job['rep']}.json"
    if out.exists():return {'file':out.name,'existing':True}
    c=cases[job['case_id']];initial={'preloaded_customer_context':c['account'],'borrower_message':c['user']}
    if c.get('preloaded_relief'):initial['previously_verified_available_options']=c['preloaded_relief']
    configuration=(R/'prompts'/f"{job['condition']}.txt").read_text();transcript=[];steps=[]
    for i in range(3):
        prompt=(R/'wrapper.txt').read_text()+'\nCONFIGURATION\n'+configuration+'\nCHAT INPUT\n'+json.dumps(initial,ensure_ascii=False)+'\nVISIBLE CONTINUATION\n'+json.dumps(transcript,ensure_ascii=False)
        if i==2:prompt+='\nThis turn must now end. Reply using only established facts; if needed facts remain unavailable, state that limitation. Return no further tool requests.'
        try:s=model_call(prompt,'gpt-6-astra',R/'schema.json',R)
        except subprocess.TimeoutExpired:s={'transport_error':'timeout_150_seconds'}
        except Exception as e:s={'transport_error':type(e).__name__+': '+str(e)[:300]}
        s['input_sha256']=hashlib.sha256(prompt.encode()).hexdigest();steps.append(s)
        response=s.get('response')
        if not response:break
        transcript.append({'assistant':response})
        if not response.get('tool_requests'):break
        for req in response['tool_requests']:transcript.append({'tool':req['name'],'result':tool_result(req,c)})
    record={**job,'utc_completed':datetime.datetime.now(datetime.timezone.utc).isoformat(),'steps':steps,'visible_transcript':transcript}
    out.write_text(json.dumps(record,indent=2,ensure_ascii=False)+'\n')
    return {'file':out.name,'calls':len(steps),'transport_ok':bool(steps[-1].get('response'))}

if __name__=='__main__':
    freeze=json.loads((R/'FREEZE.json').read_text())['sha256']
    assert all(hashlib.sha256((R/p).read_bytes()).hexdigest()==h for p,h in freeze.items()),'Frozen inputs changed'
    cases={c['id']:c for c in json.loads((R/'cases.json').read_text())}
    jobs=json.loads((R/'jobs.json').read_text())
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        for f in concurrent.futures.as_completed([pool.submit(run,j,cases) for j in jobs]):print(json.dumps(f.result()),flush=True)
