"""Optional original model transport; offline reproduction never calls it."""
import os,shutil,json,subprocess,time

def model_call(prompt, model, schema_path, workspace, effort='high'):
    cli = os.environ.get('CODEX_CLI') or shutil.which('codex')
    if not cli:
        raise RuntimeError('Set CODEX_CLI to an available Codex CLI for optional new model calls. Offline reproduction needs no CLI.')
    args = [cli, 'exec', '--ignore-user-config', '--ephemeral', '--skip-git-repo-check', '--json',
            '--sandbox', 'read-only', '--model', model, '--output-schema', str(schema_path),
            '-c', f'model_reasoning_effort="{effort}"', '-c', 'web_search="disabled"',
            '-c', 'project_doc_max_bytes=0', '-c', 'approval_policy="never"']
    for feature in ['shell_tool','multi_agent','apps','plugins','hooks','browser_use','computer_use',
                    'image_generation','sleep_tool','goals','skill_search','shell_snapshot']:
        args += ['--disable', feature]
    started = time.monotonic()
    result = subprocess.run(args + ['-'], input=prompt, text=True, capture_output=True,
                            cwd=workspace, timeout=150)
    final, usage, errors, unexpected = None, None, [], []
    for line in result.stdout.splitlines():
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        kind = event.get('type')
        if kind in ('error', 'turn.failed'):
            errors.append(event)
        if kind == 'turn.completed':
            usage = event.get('usage')
        if kind == 'item.completed':
            item = event.get('item', {})
            if item.get('type') == 'agent_message':
                final = item.get('text')
            elif item.get('type') not in ('reasoning',):
                unexpected.append(item.get('type'))
    # Preserve visible output and usage, never hidden reasoning or credentials.
    record = {'model_requested': model, 'effort_requested': effort,
              'transport': 'Codex CLI, signed-in ChatGPT, ephemeral independent invocation',
              'elapsed_seconds': round(time.monotonic() - started, 3), 'exit_code': result.returncode,
              'usage': usage, 'errors': errors, 'unexpected_item_types': unexpected, 'raw_final': final}
    if final:
        try:
            record['response'] = json.loads(final)
        except json.JSONDecodeError:
            record['parse_error'] = True
    if not final:
        record['diagnostic'] = result.stderr[-1200:]
    return record
