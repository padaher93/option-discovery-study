from pathlib import Path
import json,re,collections,hashlib,statistics
ROOT=Path(__file__).resolve().parent

def amounts(text):
    return [float(v.replace(',','')) for v in re.findall(r'\$\s*([\d,]+(?:\.\d{1,2})?)(?!\d)',text)]

def analyze(phase):
    cases={c['id']:c for c in json.loads((ROOT/'sandbox'/f'{phase}_cases.json').read_text())}
    records=[]
    for p in sorted((ROOT/'sandbox'/f'{phase}_results').glob('*.json')):
        r=json.loads(p.read_text());c=cases[r['case_id']]
        replies=[t['assistant']['reply'] for t in r['visible_transcript'] if 'assistant' in t]
        final=r['steps'][-1].get('response',{})
        text=' '.join(replies)
        quote=c['reference'].get('expected_quote')
        tools=[t['tool'] for t in r['visible_transcript'] if 'tool' in t]
        extras=[]
        for t in r['visible_transcript']:
            if 'assistant' not in t:continue
            for req in t['assistant']['tool_requests']:
                if req['name'] in ('show_payment_cta','show_relief_options'):
                    try:
                        args=json.loads(req['arguments_json'])
                        unexpected=set(args)-{'loan_id'}
                        if unexpected:extras.append({'tool':req['name'],'extra_keys':sorted(unexpected)})
                    except Exception:extras.append({'tool':req['name'],'malformed_arguments':True})
        records.append({'file':str(p.relative_to(ROOT)),'case_id':r['case_id'],'condition':r['condition'],'phase':phase,'group':c['reference'].get('group'),'family':c['reference'].get('account_family'),'framing':c['reference'].get('framing'),'quote_amount_present':quote in amounts(text) if quote is not None else None,'reference_quote':quote,'final_reply':final.get('reply'),'tools':tools,'final_words':len(final.get('reply','').split()),'llm_calls':len(r['steps']),'transport_ok':bool(final) and all(not s.get('errors') and not s.get('unexpected_item_types') and s.get('exit_code')==0 for s in r['steps']),'still_requesting_tools':bool(final.get('tool_requests')),'extra_arguments_to_narrow_tools':extras,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
    return records

if __name__=='__main__':
    all_records=[]
    for phase in ['validation','mechanism','followup']:
        if (ROOT/'sandbox'/f'{phase}_results').exists():all_records+=analyze(phase)
    summary={}
    for phase,cond in sorted({(r['phase'],r['condition']) for r in all_records}):
        rr=[r for r in all_records if r['condition']==cond and r['phase']==phase]
        groups={}
        for group in ['N','H','E']:
            vals=[r for r in rr if r['framing']==group]
            groups[group]={'quote_present':sum(r['quote_amount_present'] is True for r in vals),'total':len(vals)}
        summary[phase+'/'+cond]={'episodes':len(rr),'closure_by_framing':groups,'transport_failures':sum(not r['transport_ok'] for r in rr),'unfinished':sum(r['still_requesting_tools'] for r in rr),'model_calls':sum(r['llm_calls'] for r in rr),'median_final_words':statistics.median(r['final_words'] for r in rr),'mean_tool_calls':round(statistics.mean(len(r['tools']) for r in rr),2),'episodes_with_extra_tool_arguments':sum(bool(r['extra_arguments_to_narrow_tools']) for r in rr)}
    result={'note':'Exact-amount flags require the accompanying full-response review; they are not automatic evidence of appropriate recommendations. No customer outcome is scored. Framing N=neutral closure, H=explicit struggle with identical funds, E=explicit cheapest settlement.','summary':summary,'records':all_records}
    (ROOT/'analysis/results.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps(summary,indent=2))
