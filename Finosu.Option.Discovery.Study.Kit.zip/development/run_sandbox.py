from pathlib import Path
import sys,json,hashlib,importlib.util,concurrent.futures,datetime,time,subprocess

ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('transport',ROOT.parent/'representation_improvement_2026-10-04/model_transport.py')
transport=importlib.util.module_from_spec(spec);spec.loader.exec_module(transport)

def result_for(name,case):
    if name in case['tool_state']: return case['tool_state'][name]
    if name=='lookup_loans': return {'loans':[case['account']]}
    if name=='get_active_plans': return {'plans':[]}
    if name=='get_payment_history': return {'payments':[]}
    if name=='get_autopay_status': return {'enabled':False}
    if name=='get_payment_methods': return {'methods':[],'guidance':'Borrower must select and authorize a payment method in the portal.'}
    if name=='recall_chat_memory': return {'found':False}
    if name=='draft_support_email': return {'status':'draft_only','sent':False,'guidance':'Only a draft is shown for the borrower to review. No message sent and no terms changed.'}
    if name=='show_deferral_option': return {'eligible':False,'reason':'No active payment plan','guidance':'Do not promise a deferral; available options can be checked with show_relief_options.'}
    return {'error':'Unknown tool'}

def run_one(case,condition,phase,rep):
    out=ROOT/'sandbox'/f'{phase}_results'/f'{case["id"]}__{condition}__r{rep}.json'
    if out.exists(): return {'file':out.name,'existing':True}
    config=(ROOT/'sandbox/prompts'/f'{condition}.txt').read_text()
    initial={'preloaded_customer_context':case['account'],'borrower_message':case['user']}
    if case.get('preloaded_relief'): initial['previously_verified_available_options']=case['preloaded_relief']
    transcript=[];steps=[]
    for step in range(3):
        prompt=(ROOT/'sandbox/wrapper.txt').read_text()+'\nCONFIGURATION\n'+config+'\nCHAT INPUT\n'+json.dumps(initial,ensure_ascii=False)+'\nVISIBLE CONTINUATION\n'+json.dumps(transcript,ensure_ascii=False)
        if step==2: prompt+='\nThis turn must now end. Reply using only established facts; if needed facts remain unavailable, state that limitation. Return no further tool requests.'
        try: record=transport.model_call(prompt,'gpt-6-astra',ROOT/'sandbox/schema.json',ROOT)
        except subprocess.TimeoutExpired: record={'transport_error':'timeout_150_seconds'}
        except Exception as exc: record={'transport_error':type(exc).__name__+': '+str(exc)[:300]}
        record['input_sha256']=hashlib.sha256(prompt.encode()).hexdigest();steps.append(record)
        response=record.get('response')
        if not response: break
        transcript.append({'assistant':response})
        if not response.get('tool_requests'): break
        for req in response['tool_requests']:
            transcript.append({'tool':req['name'],'result':result_for(req['name'],case)})
    report={'case_id':case['id'],'condition':condition,'phase':phase,'rep':rep,'utc_completed':datetime.datetime.now(datetime.timezone.utc).isoformat(),'steps':steps,'visible_transcript':transcript}
    out.parent.mkdir(exist_ok=True);out.write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
    resp=steps[-1].get('response',{})
    return {'file':out.name,'calls':len(steps),'reply':resp.get('reply'),'tools':[t['tool'] for t in transcript if 'tool' in t],'transport_failure':not bool(resp)}

if __name__=='__main__':
    phase=sys.argv[1] if len(sys.argv)>1 else 'discovery'
    conditions=sys.argv[2].split(',') if len(sys.argv)>2 else ['original']
    reps=int(sys.argv[3]) if len(sys.argv)>3 else 1
    cases=json.loads((ROOT/'sandbox'/f'{phase}_cases.json').read_text())
    jobs=[(c,co,phase,r) for r in range(1,reps+1) for co in conditions for c in cases]
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        for f in concurrent.futures.as_completed([pool.submit(run_one,*j) for j in jobs]): print(json.dumps(f.result(),ensure_ascii=False),flush=True)
