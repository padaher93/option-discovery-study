"""Read-only reproduction of descriptive results; standard library, no network."""
from pathlib import Path
from collections import Counter
import json,hashlib,re,statistics
K=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((K/'MANIFEST.json').read_text())['files']
for name,h in manifest.items():assert sha(K/name)==h,('Archive integrity mismatch',name)
freeze=json.loads((K/'final/FREEZE.json').read_text())['sha256'];omitted=[]
for name,h in freeze.items():
    p=K/'final'/name
    if p.exists():assert sha(p)==h,('Final frozen input changed',name)
    else:
        assert name in ['prompts/original.txt','prompts/generic.txt','prompts/resolution_v2.txt']
        omitted.append(name)
assert json.loads((K/'evidence/BASELINE.json').read_text())['baseline_sha256']==freeze['prompts/original.txt']
cases={c['id']:c for c in json.loads((K/'final/cases.json').read_text())};assert len(cases)==24
for i in range(1,9):
    n=cases[f'A{i:02}N'];e=cases[f'A{i:02}E']
    assert n['account']==e['account'] and n['tool_state']==e['tool_state'] and e['user'].startswith(n['user'])
review=json.loads((K/'final/analysis/review.json').read_text())['labels']
saved=json.loads((K/'final/analysis/results.json').read_text());assert len(review)==144
recorded={r['file']:r for r in saved['records']}
rows=[]
for p in sorted((K/'final/results').glob('*.json')):
    x=json.loads(p.read_text());c=cases[x['case_id']];label=review[p.name];r=recorded[p.name]
    assert sha(p)==r['sha256']
    final=x['steps'][-1]['response'];assert not final['tool_requests']
    assert all(s['exit_code']==0 and not s['errors'] and not s['unexpected_item_types'] for s in x['steps'])
    events=[t for t in x['visible_transcript'] if 'tool' in t]
    assert all('error' not in t['result'] for t in events)
    primary=x['case_id'].startswith('A');disclosed=label['settlement_disclosed']
    values=[float(v.replace(',','')) for v in re.findall(r'\$\s*([\d,]+(?:\.\d{1,2})?)(?!\d)',final['reply'])]
    if primary:
        assert (c['reference']['quote'] in values)==disclosed
        assert ('show_relief_options' in [t['tool'] for t in events])==disclosed
    for t in x['visible_transcript']:
        if 'assistant' in t:
            for req in t['assistant']['tool_requests']:
                if req['name'] in ['show_payment_cta','show_relief_options']:assert not set(json.loads(req['arguments_json']))-{'loan_id'}
    rows.append({'id':x['case_id'],'arm':x['condition'],'rep':x['rep'],'group':c['group'],'disclosed':disclosed,'label':label,'calls':len(x['steps']),'tools':len(events),'words':len(final['reply'].split())})
assert len(rows)==144 and sum(r['calls'] for r in rows)==301
summary={}
for arm,expected in [('original',0),('generic',1),('resolution_v2',16)]:
    rr=[r for r in rows if r['arm']==arm];assert len(rr)==48
    n=[r for r in rr if r['group']=='neutral'];e=[r for r in rr if r['group']=='explicit'];c=[r for r in rr if r['id'].startswith('C')]
    assert len(n)==len(e)==len(c)==16
    assert sum(r['disclosed'] for r in n)==expected
    assert sum(r['disclosed'] for r in e)==16
    assert sum(r['label']['boundary_pass'] for r in c)==16
    complete=sum(all(any(r['id']==f'A{i:02}{w}' and r['rep']==rep and r['disclosed'] for r in rr) for w in ['N','E'] for rep in [1,2]) for i in range(1,9))
    flags=sum(r['label']['navigation_ambiguity'] for r in rr)
    assert complete==saved['summary'][arm]['all_four_pair_responses_families']
    assert flags==saved['summary'][arm]['review_flags']['unsupported_statement']
    summary[arm]={'neutral_disclosure':f'{expected}/16','explicit_disclosure':'16/16','boundary_checks':'16/16','complete_families':f'{complete}/8','neutral_median_words':statistics.median(r['words'] for r in n),'neutral_mean_tool_requests':statistics.mean(r['tools'] for r in n),'navigation_flags':f'{flags}/48'}
development={};all_old=[]
for phase,count in [('discovery',8),('validation',54),('mechanism',12),('followup',26),('repair',1)]:
    rr=[json.loads(p.read_text()) for p in (K/f'development/sandbox/{phase}_results').glob('*.json')]
    assert len(rr)==count,(phase,len(rr));all_old+=rr;development[phase]=count
assert len(all_old)==101 and sum(len(r['steps']) for r in all_old)==196
for p in (K/'development/sandbox').glob('*freeze.json'):
    f=json.loads(p.read_text());f=f.get('sha256',f)
    for name,h in f.items():
        target=K/'development'/name
        if target.exists():assert sha(target)==h,('Development frozen input changed',name)
        else:assert name.startswith('sandbox/prompts/'),('Unexpected missing freeze member',name)
def quote_present(r,c):
    text=' '.join(t['assistant']['reply'] for t in r['visible_transcript'] if 'assistant' in t)
    amounts=[float(v.replace(',','')) for v in re.findall(r'\$\s*([\d,]+(?:\.\d{1,2})?)(?!\d)',text)]
    return c['reference'].get('expected_quote') in amounts
mechanism={}
for phase in ['validation','mechanism']:
    cc={c['id']:c for c in json.loads((K/f'development/sandbox/{phase}_cases.json').read_text())}
    rr=[r for r in all_old if r.get('phase')==phase and r['condition'] in ['original','preloaded'] and cc[r['case_id']]['reference'].get('framing')=='N']
    mechanism[phase]={'n':len(rr),'disclosed_quote':sum(quote_present(r,cc[r['case_id']]) for r in rr)}
assert mechanism['validation']=={'n':4,'disclosed_quote':0}
assert mechanism['mechanism']=={'n':4,'disclosed_quote':4}
human=json.loads((K/'human_review/labels.json').read_text())['rows']
assert len(human)==96 and len({r['review_id'] for r in human})==96
assert {r['file'] for r in human}=={f for f,r in recorded.items() if r['group'] in ['neutral','explicit']}
human_counts={};confusion={a:{b:0 for b in ['Yes','No','Unclear']} for a in ['Yes','No']};disagreements=[]
for h in human:
    assert h['label'] in ['Yes','No','Unclear'] and h['evidence'].strip()
    raw=json.loads((K/'final/results'/h['file']).read_text())
    assert sha(K/'final/results'/h['file'])==h['source_sha256']
    assert all(h[k]==raw[k] for k in ['case_id','condition','rep'])
    assert h['group']==cases[h['case_id']]['group'] and h['family']==cases[h['case_id']]['family']
    ai='Yes' if review[h['file']]['settlement_disclosed'] else 'No'
    confusion[ai][h['label']]+=1
    if ai!=h['label']:disagreements.append(h['review_id'])
for arm in ['original','generic','resolution_v2']:
    human_counts[arm]={}
    for group in ['neutral','explicit']:
        rr=[r for r in human if r['condition']==arm and r['group']==group]
        assert len(rr)==16 and len({r['family'] for r in rr})==8
        assert all(sum(r['family']==family for r in rr)==2 for family in {r['family'] for r in rr})
        human_counts[arm][group]={label:sum(r['label']==label for r in rr) for label in ['Yes','No','Unclear']}
assert [human_counts[a]['neutral']['Yes'] for a in ['original','generic','resolution_v2']]==[0,1,16]
assert [human_counts[a]['explicit']['Yes'] for a in ['original','generic','resolution_v2']]==[16,14,11]
assert [human_counts[a]['explicit']['Unclear'] for a in ['original','generic','resolution_v2']]==[0,2,5]
assert confusion=={'Yes':{'Yes':58,'No':0,'Unclear':7},'No':{'Yes':0,'No':31,'Unclear':0}}
print(json.dumps({'verified':True,'public_files_hashed':len(manifest),'private_frozen_inputs_omitted':omitted,'final_trajectories':144,'final_model_invocations':301,'conditions':summary,'human_review':{'responses':96,'accounts':8,'runs_per_account_per_wording_per_prompt':2,'conditions':human_counts,'confusion_ai_to_human':confusion,'exact_agreement':'89/96','unresolved_review_ids':disagreements},'development_trajectories':development,'preload_probe':mechanism,'total_debt_resolution_trajectories':245,'total_model_invocations':497,'judgment_limit':'Counts reproduce supplied AI and human judgments without adjudicating their disagreements.'},indent=2))
