"""Prepare local synthetic runs; makes no model or network request."""
from pathlib import Path
import argparse,json,hashlib,shutil,datetime,random
P=argparse.ArgumentParser(description=__doc__)
P.add_argument('--baseline',required=True,type=Path)
P.add_argument('--output',required=True,type=Path)
P.add_argument('--case-id',action='append',help='Optional case filter; repeat for several messages.')
A=P.parse_args();K=Path(__file__).resolve().parent
if A.output.exists():P.error('Output must be a new directory; existing files are never overwritten.')
text=A.baseline.read_text();cases=json.loads((K/'final/cases.json').read_text())
if A.case_id:
    unknown=set(A.case_id)-{c['id'] for c in cases}
    if unknown:P.error('Unknown case IDs: '+', '.join(sorted(unknown)))
    cases=[c for c in cases if c['id'] in A.case_id]
A.output.mkdir(parents=True);(A.output/'prompts').mkdir();(A.output/'results').mkdir();(A.output/'analysis').mkdir()
(A.output/'prompts/original.txt').write_text(text)
for arm in ['generic','resolution_v2']:(A.output/f'prompts/{arm}.txt').write_text(text+(K/f'interventions/{arm}.txt').read_text())
for f in ['run.py','model_transport.py','schema.json','wrapper.txt']:shutil.copy2(K/'final'/f,A.output/f)
(A.output/'cases.json').write_text(json.dumps(cases,indent=2,ensure_ascii=False)+'\n')
jobs=[{'case_id':c['id'],'condition':a,'rep':r} for c in cases for a in ['original','generic','resolution_v2'] for r in [1,2]]
random.Random(20261004).shuffle(jobs)
(A.output/'jobs.json').write_text(json.dumps(jobs,indent=2)+'\n')
(A.output/'PROTOCOL.txt').write_text('Adaptation study prepared from the Finosu option-discovery companion. Same synthetic tool contract and frozen additions; locally supplied baseline. No model calls made by preparation. Record any future deviations. Results do not reproduce the private Finosu baseline unless its hash matches. Model inference is optional and uses the separately invoked runner.\n')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=['run.py','model_transport.py','schema.json','wrapper.txt','cases.json','jobs.json','PROTOCOL.txt']+[f'prompts/{a}.txt' for a in ['original','generic','resolution_v2']]
(A.output/'FREEZE.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sha256':{p:sha(A.output/p) for p in files}},indent=2)+'\n')
tested=json.loads((K/'evidence/BASELINE.json').read_text())['baseline_sha256']
print(json.dumps({'prepared_jobs':len(jobs),'output':str(A.output.resolve()),'baseline_matches_private_study_hash':sha(A.output/'prompts/original.txt')==tested,'model_calls_made':0},indent=2))
