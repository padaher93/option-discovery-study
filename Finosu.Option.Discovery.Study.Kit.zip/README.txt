Finosu — Customer Interests and Option Discovery

Read first: final/FINAL_FINDINGS.txt. This is a completed synthetic study, not a deployment.

Offline reproduction (Python 3, standard library only):
    python3 verify.py

This checks SHA-256 integrity, all public frozen inputs, case pairing, preserved trace hashes, the original AI labels and counts, the development sequence, and all 96 anonymized human labels with disagreements. It makes no model or network call. The verifier reproduces supplied judgments; it does not itself validate their semantic correctness.

Download the versioned study kit from https://github.com/padaher93/option-discovery-study/releases/tag/v1.0.0. Extract the ZIP before running the offline verifier. SHA256SUMS.txt identifies the exact release archive.

Contribution: a customer's goal can trigger investigation of authorized alternatives without requiring them to know the option's name or disclose hardship. The exact instruction and matched-request tests let another team examine this behavior in its own configuration.

Prompt provenance: the additions were generated for the research experiment, not copied from a production system prompt. paper/public_examples/instruction_examples.json presents the additions with a neutral lookup_options tool alias. The recorded experimental additions and traces retain their tested identifiers for verification. The production baseline is not included. Paper conditions Original prompt / Borrower interest reminder / Check options rule correspond to saved condition identifiers original / generic / resolution_v2. Recorded research files retain their original condition labels.

Final design: eight variations of one core account situation with neutral/explicit wording (16 messages), eight separate boundary situations, three configurations, two independent draws per message. 144 trajectories; 301 invocations. Original prompt / Borrower interest reminder / Check options rule neutral settlement disclosure: 0/16, 1/16, 16/16. Explicit requests: 16/16 in all three. Specified control checks: 16/16 in all three. Navigation wording flags: 1/48, 1/48, 7/48; these are potential unsupported route or price implications, not observed failed payments. Read the per-response notes. Longer replies and more lookups accompany the gain. There is no measured savings or trust result. Frozen data retain the original label 'families' for the eight main case instances; this does not denote eight distinct financial problem types.

The preceding counts describe the original AI scoring. Subsequent human review reproduced neutral results exactly. For explicit requests, human Yes / No / Unclear counts were Original 16/0/0, Borrower interest reminder 14/0/2, Check options rule 11/0/5, each across eight accounts with two runs each. Exact agreement was 89/96; seven AI Yes labels became human Unclear, with no Yes/No reversals. Read their explanations. Initial AI labels remain unchanged in final/analysis. The paper now presents the human comparison in Table 1. Controls and wording flags remain AI-scored.

Directory map:
  final/cases.json — frozen facts, messages, tool results and references.
  final/results/ — all 144 visible traces, requested-model metadata and usage.
  final/analysis/review.json — full-response labels and caveats.
  final/analysis/results.json — recorded final metrics and trace hashes.
  human_review/ — anonymized human judgments, supporting explanations, source mapping and review protocol.
  interventions/ — exact General and Scoped additions, preserving whitespace.
  final/FREEZE.json — pre-inference hash commitments, including private inputs.
  development/ — preceding 101 traces (196 invocations), cases, freezes and v1/v2 additions. Do not pool its changing conditions with the final comparison.
  evidence/ — aggregate grounding, source boundaries and private-baseline hash.
  paper/ — anonymized research instructions and explanatory figures. Illustration production notes and the outdated manuscript snapshot are omitted from this research-materials release.

Inspect a single example: final/results/A01N__original__r1.json versus final/results/A01N__resolution_v2__r1.json. Both have access to the same $384 settlement for a $640 balance. Their replies differ because the latter retrieves it.

Optional adaptation / new model calls:
    python3 prepare_run.py --baseline /absolute/path/to/your_prompt.txt --output /absolute/path/to/new_empty_run
Review the prepared files. To run afterwards with an authorized signed-in compatible Codex CLI:
    CODEX_CLI=/absolute/path/to/codex python3 /absolute/path/to/new_empty_run/run.py
The default preparation creates 144 jobs. --case-id A01N can prepare a smaller smoke check. Preparing is local and does not call a model. Running consumes model usage; requested alias availability and CLI compatibility may vary. All external tools of the model are disabled; only deterministic synthetic tool results are supplied. Never give the runner live borrower data. No output is a production instruction or payment authorization.

Supply your own assembled baseline with compatible tool descriptions. The full tested Finosu baseline is private. Its hash is included; exact new inference cannot be reproduced from this public bundle alone. Applying the additions to a different baseline is an adaptation study. Case IDs and references are excluded from inference by the original runner. No behavior-based retries or post-result prompt tuning should be reported as held-out validation.

No live customer records, private repository code, production identifiers or credentials are included. Fictional UUIDs and example.test URLs are deliberate fixtures. Do not confuse recorded draft requests with messages sent, proposed review actions with payments, or quoted settlement reductions with realized savings.
